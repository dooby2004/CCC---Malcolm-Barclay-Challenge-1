<html>
<head>
	<title>Infiltrating Accounts</title>
	<style type="text/css">
		body{
			margin:40px auto;
			max-width:650px;
			line-height:1.6;
			font-size:18px;
			color:#444;
			padding:010px;
			background-color: #FFFFFF;
		}
		h1,h2,h3{
			line-height:1.2;
		}
		a{
			text-decoration: none;
			color: blue;
		}
		a:hover{
			text-decoration: underline;
		}
	</style>
</head>
<body>
	<?php
	$header = htmlspecialchars($_GET["UserID"]);
	if (!ctype_alnum($header)) {
		die ("The UserID is not alphanumeric.");
	}
	$file = fopen("./Users/" . $header, "r") or die ("Unable to open file!");
	$lines = file("./Users/" . $header, FILE_IGNORE_NEW_LINES);
	fclose($file);
	?>
	<h1><?php echo $lines[0] ?>'s Files</h1>
	<h6>Folder ID: <?php echo $lines[1] ?></h6>
	<h3>Files:</h3>
	<?php
	for ($x = 2; $x < count($lines); $x++) {
		if (substr($lines[$x], 0, 2) != "-h") {
			$lines[$x] = ucfirst($lines[$x]);
			echo "<a href=\"./Files/" . $lines[$x] . "\">" . $lines[$x] . "</a> <br />";
		}
		else {
			$lines[$x] = ucFirst(substr($lines[$x], 2, strlen($lines[$x])-2));
			echo "<a hidden href=\"./Files/" . $lines[$x] . "\">" . $lines[$x] . "</a> <br />";
		}
	}
	?>
</body>
</html>